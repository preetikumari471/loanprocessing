package com.cg.laps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.laps.bean.CustomerBean;
import com.cg.laps.bean.LoanApplicationBean;
import com.cg.laps.exception.LoanProcessingException;
import com.cg.laps.util.DBUtil;
import com.cg.laps.util.IQueryMapper;

public class CustomerDaoImpl implements ICustomerDao {
	static Connection conn;
	static PreparedStatement preparedstatement = null;
	static ResultSet rs = null;
	boolean result = false;
	Logger logger = Logger.getRootLogger();

	public CustomerDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");

	}
	
	
	//------------------------ 1. Loan Application Processing System --------------------------
			/*******************************************************************************************************
			 - Function Name	:	addApplicationDetails(LoanApplicationBean loanApplication)
			 - Input Parameters	:	loanApplication
			 - Return Type		:	String
			 - Throws			:  	LoanProcessingException
			 - Author			:	Preeti Kumari
			 - Creation Date	:	18//2018
			 - Description		:	Add loan application form details
			 ********************************************************************************************************/


	@Override
	public String addApplicationDetails(LoanApplicationBean loanApplication)
			throws LoanProcessingException {

		int queryResult = 0;
		String applicationId = null;
		String generatedColumns[] = { "APPLICATION_ID"};
		conn = DBUtil.establishConnection();
		try {
			preparedstatement = conn.prepareStatement(IQueryMapper.INSERT_QUERY_APPLICATION_DETAILS, generatedColumns);

			preparedstatement.setString(1, loanApplication.getLoanProgram());
			preparedstatement.setDouble(2, loanApplication.getLoanAmount());
			preparedstatement.setString(3, loanApplication.getPropertyAddress());
			preparedstatement.setDouble(4, loanApplication.getAnnualFamilyIncome());
			preparedstatement.setString(5, loanApplication.getDocsProof());
			preparedstatement.setString(6, loanApplication.getGuaranteeCoverString());
			preparedstatement.setDouble(7, loanApplication.getMarktValOfCover());

			int affectedRows = preparedstatement.executeUpdate();
			
			if (affectedRows == 0) 
	            throw new LoanProcessingException("Creating User's Account Failed");
			
			try (ResultSet generatedKeys = preparedstatement.getGeneratedKeys()) {
	             if (generatedKeys.next()) 
	            	 applicationId = generatedKeys.getString(1);
	             
	         	} 
	         catch (SQLException e) {
	        	 throw new LoanProcessingException("Error Getting Application ID for added customer");
	         }
			}

		 catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new LoanProcessingException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedstatement.close();
				conn.close();
			}

			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new LoanProcessingException(
						"Error in closing db connection");

			}
		}

		return applicationId;
	}
	
	

	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addPersonalDetails(LoanApplicationBean loanApplication)
	 - Input Parameters	:	loanApplication
	 - Return Type		:	String
	 - Throws			:  	LoanProcessingException
	 - Author			:	Preeti Kumari
	 - Creation Date	:	18//2018
	 - Description		:	Add personal details for loan application form
	 ********************************************************************************************************/
	@Override
	public boolean addPersonalDetails(CustomerBean customer)
			throws LoanProcessingException {

		int queryResult = 0;

		conn = DBUtil.establishConnection();
		try {
			preparedstatement = conn.prepareStatement(IQueryMapper.INSERT_QUERY_CUSTOMER_DETAILS);
			preparedstatement.setString(1, customer.getApplicationId());
			preparedstatement.setString(2, customer.getApplicantName());
			preparedstatement.setString(3, customer.getDateOfBirth());
			preparedstatement.setString(4, customer.getMaritalStatus());
			preparedstatement.setString(5, customer.getPhoneNumber());
			preparedstatement.setString(6, customer.getMobileNumber());
			preparedstatement.setDouble(7, customer.getDependentsCount());
			preparedstatement.setString(8, customer.getEmailId());

			queryResult = preparedstatement.executeUpdate();

			if (queryResult == 1) {
				logger.info("Customer details added successfully!!");

			} else {
				
				logger.error("Insertion failed ");
				throw new LoanProcessingException("Inserting customer details failed ");
				
			}

		} catch (SQLException sqlException) {
			logger.error(sqlException.getMessage());
			throw new LoanProcessingException("Tehnical problem occured refer log");
		}

		finally {
			try {
				preparedstatement.close();
				conn.close();
			}

			catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new LoanProcessingException("Error in closing db connection");

			}
		}

		return true;
	}
	
	//------------------------ 1. Loan Application Processing System --------------------------
	/*******************************************************************************************************
	 - Function Name	:	viewApplicationStatus(String appid)
	 - Input Parameters	:	appid
	 - Return Type		:	String
	 - Throws			:  	-
	 - Author			:	Preeti Kumari
	 - Creation Date	:	18//2018
	 - Description		:	View status of loan application
	 ********************************************************************************************************/
	@Override
	public String viewApplicationStatus(String appid) {

		String appstatus = null;
		try {
			conn = DBUtil.establishConnection();
			preparedstatement = conn.prepareStatement(IQueryMapper.VIEW_STATUS);
			preparedstatement.setString(1, appid);
			ResultSet rs = preparedstatement.executeQuery();
			while (rs.next()) {
				appstatus = rs.getString(1);

			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return appstatus;
	}

}

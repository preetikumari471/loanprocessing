package com.cg.laps.exception;


public class LoanProcessingException extends Exception {
	private static final long serialVersionUID = 726264577455921591L;

	public LoanProcessingException(String message) {
			
			super(message);
		
	}

}

package com.cg.laps.service;

import java.util.ArrayList;

import com.cg.laps.bean.LoanApplicationBean;
import com.cg.laps.dao.AdminDaoImpl;
import com.cg.laps.dao.LoanApprovalDepartmentDaoImpl;

public class AdminServiceImpl implements IAdminService {

	AdminDaoImpl adminDao = null;

}

package com.cg.laps.service;

import com.cg.laps.bean.CustomerBean;
import com.cg.laps.bean.LoanApplicationBean;
import com.cg.laps.exception.LoanProcessingException;

public interface ICustomerService {

	

	boolean addPersonalDetails(CustomerBean customer) throws LoanProcessingException;

	String addApplicationDetails(LoanApplicationBean loanApplication) throws LoanProcessingException;

	

	String viewApplicationStatus(String appid);

	boolean isValidEmail(String email);

	boolean isValidName(String donorName);

	boolean validateApplicationId(String applicationId);

	boolean isValidAddress(String address);

	boolean isValidPhoneNo(String PhoneNo);

	boolean isValidMobileNo(String MobileNo);

	boolean isValidDate(String dateOfBirth);

}

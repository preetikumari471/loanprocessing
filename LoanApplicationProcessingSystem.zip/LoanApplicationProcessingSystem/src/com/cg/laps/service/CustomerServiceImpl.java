package com.cg.laps.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.laps.bean.CustomerBean;
import com.cg.laps.bean.LoanApplicationBean;
import com.cg.laps.dao.CustomerDaoImpl;
import com.cg.laps.exception.LoanProcessingException;

public class CustomerServiceImpl implements ICustomerService {

	static CustomerDaoImpl customerDao = null;

	/*public void validateCustomer(CustomerBean customer) throws LoanProcessingException {
		List<String> validationErrors = new ArrayList<String>();

		//Validating customer name
		if(!(isValidName(customer.getApplicantName()))) {
			validationErrors.add("\n Applicant Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validating address
		if(!(isValidMobileNo(customer.getMobileNumber()))){
			validationErrors.add("\n Mobile number Should Be 10 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNo(customer.getPhoneNumber()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating emailId
		if(!(isValidEmail(customer.getEmailId()))){
			validationErrors.add("\n email should be in the form abc@xyz.com \n" );
		}
		
		if(!validationErrors.isEmpty())
			throw new LoanProcessingException(validationErrors +" ");
	}
	
	
	*/
	
	
	@Override
	public boolean validateApplicationId(String applicationId) {
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(applicationId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
		
	}
		
	
	@Override
	public boolean isValidName(String applicantName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(applicantName);
		return nameMatcher.matches();
	}
	
	@Override
	public boolean isValidDate(String dateOfBirth){
		Pattern datePattern=Pattern.compile("(0?[1-9]|[12][0-9]|3[01])-(0?[1-9]|1[012])-((19|20)\\d\\d)");
		Matcher dateMatcher=datePattern.matcher(dateOfBirth);
		return dateMatcher.matches();
	}
	
	@Override
	public boolean isValidPhoneNo(String PhoneNo){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(PhoneNo);
		return phoneMatcher.matches();
		
	}
	
	@Override
	public boolean isValidMobileNo(String MobileNo) {
		Pattern p = Pattern.compile("(9|8|7|6){1}[0-9]{9}$");
		Matcher m = p.matcher(MobileNo);
		return m.matches();
	}
	
	
	@Override
	public boolean isValidEmail(String email) {

		Pattern p = Pattern.compile("^([_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*(\\.[a-zA-Z]{1,6}))?$");
		Matcher m = p.matcher(email);
		return m.matches();
	}


	
	
	@Override
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	

	@Override
	public String addApplicationDetails(LoanApplicationBean loanApplication) throws LoanProcessingException {
		customerDao = new CustomerDaoImpl();
		return customerDao.addApplicationDetails(loanApplication);

	}

	@Override
	public boolean addPersonalDetails(CustomerBean customer) throws LoanProcessingException {
		customerDao = new CustomerDaoImpl();
		return customerDao.addPersonalDetails(customer);
	}

	@Override
	public String viewApplicationStatus(String appid) {
		customerDao = new CustomerDaoImpl();
		return customerDao.viewApplicationStatus(appid);
	}





	
}
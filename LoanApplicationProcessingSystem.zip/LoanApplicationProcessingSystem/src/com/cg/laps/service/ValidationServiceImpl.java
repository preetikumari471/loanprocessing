package com.cg.laps.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.laps.bean.CustomerBean;
import com.cg.laps.exception.LoanProcessingException;


public class ValidationServiceImpl implements IValidationService {
	
	
	
	
	
	
	
	
	
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	

	
		
	}



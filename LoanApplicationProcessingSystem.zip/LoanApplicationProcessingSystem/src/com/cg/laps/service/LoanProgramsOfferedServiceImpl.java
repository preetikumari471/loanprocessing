package com.cg.laps.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.laps.bean.LoanProgramsOfferedBean;
import com.cg.laps.dao.LoanProgramsOfferedDaoImpl;
import com.cg.laps.exception.LoanProcessingException;

public class LoanProgramsOfferedServiceImpl implements
		ILoanProgramsOfferedService {
	static LoanProgramsOfferedDaoImpl loanProgramsOfferedDao = null;

	@Override
	public int addLoanProgramsOffered(
			LoanProgramsOfferedBean loanProgramsOffered) throws LoanProcessingException {

		loanProgramsOfferedDao = new LoanProgramsOfferedDaoImpl();
		return loanProgramsOfferedDao.addLoanPrograms(loanProgramsOffered);

	}

	@Override
	public int deleteLoanProgramsOffered(String dltprogram) {

		loanProgramsOfferedDao = new LoanProgramsOfferedDaoImpl();
		return loanProgramsOfferedDao.deleteLoanPrograms(dltprogram);

	}

	@Override
	public boolean validateLoanProgram(String loanProgram) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{1,6}$");
		Matcher nameMatcher=namePattern.matcher(loanProgram);
		return nameMatcher.matches();
	}
	@Override
	public boolean validateLoanDescription(String loanDesc) {
		Pattern namePattern=Pattern.compile("^[A-Za-z ]{1,20}$");
		Matcher nameMatcher=namePattern.matcher(loanDesc);
		return nameMatcher.matches();
	}
	@Override
	public boolean validateLoanType(String loanType) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{1,6}$");
		Matcher nameMatcher=namePattern.matcher(loanType);
		return nameMatcher.matches();
		
	}

	public boolean validateProof(String proof) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{1,20}$");
		Matcher nameMatcher=namePattern.matcher(proof);
		return nameMatcher.matches();
	}

}
